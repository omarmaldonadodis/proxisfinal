# app/core/__init__.py
"""Core functionality"""