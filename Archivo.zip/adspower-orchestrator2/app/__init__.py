# app/__init__.py
"""
AdsPower Orchestrator - Sistema de orquestación distribuida
"""

__version__ = "1.0.0"
__author__ = "Omar - Conecta Studio"